const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());


app.post("/login", (req, res) => {
  const users = JSON.parse(fs.readFileSync("../backend/users.json"));
  const {username, password} = req.body;
  const valid = users.find(u => u.username === username && u.password === password);
  res.json({success: !!valid});
});

app.post("/book", (req, res) => {

    const booking = req.body;

    const data = JSON.parse(fs.readFileSync("../backend/data.json"));
    data.push(booking);
    fs.writeFileSync("../backend/data.json", JSON.stringify(data, null, 2));

    res.json(booking);
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
