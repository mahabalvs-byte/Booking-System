const form = document.getElementById("bookingForm");
const ticketList = document.getElementById("ticketList");

form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const booking = {
        name: name.value,
        from: from.value,
        to: to.value,
        date: date.value
    };

    const response = await fetch("http://localhost:3000/book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(booking)
    });

    const data = await response.json();
    displayTicket(data);
});

function displayTicket(ticket) {
    const li = document.createElement("li");
    li.textContent = `${ticket.name} | ${ticket.from} → ${ticket.to} | ${ticket.date}`;
    ticketList.appendChild(li);
}
