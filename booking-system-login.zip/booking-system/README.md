# IRCTC-like Train Booking System

Open this folder in VS Code to run the project.